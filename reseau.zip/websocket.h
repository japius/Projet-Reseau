#ifndef WEBSOCKET_H
#define WEBSOCKET_H
#include <libwebsockets.h>

void handle_gui();
#endif